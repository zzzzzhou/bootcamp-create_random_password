from password import *
from store import *

newpassword = passwd()
ID = input("what is password ID")
up = input("update or not")
if up == 'y':
    update("password.csv", newpassword, ID)
else:
    retornot = input("retrieve or not?")
    if retornot == 'y':
        reID = input("retrieve which ID's password?")
        oldpassword = retrieve("password.csv", reID)
        print("oldpassword of",reID, "is", oldpassword)
    else:
        print("program done")
